singlecellmultiomics.fastqProcessing package
============================================

Submodules
----------

singlecellmultiomics.fastqProcessing.fastqHandle module
-------------------------------------------------------

.. automodule:: singlecellmultiomics.fastqProcessing.fastqHandle
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.fastqProcessing.fastqIterator module
---------------------------------------------------------

.. automodule:: singlecellmultiomics.fastqProcessing.fastqIterator
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: singlecellmultiomics.fastqProcessing
   :members:
   :undoc-members:
   :show-inheritance:
