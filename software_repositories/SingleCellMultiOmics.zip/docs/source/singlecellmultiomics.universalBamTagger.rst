singlecellmultiomics.universalBamTagger package
===============================================

Submodules
----------

singlecellmultiomics.universalBamTagger.4SUtagger module
--------------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.4SUtagger
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.universalBamTagger.bamtagmultiome module
-------------------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.bamtagmultiome
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.universalBamTagger.customreads module
----------------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.customreads
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.universalBamTagger.digest module
-----------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.digest
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.universalBamTagger.mspjI module
----------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.mspjI
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.universalBamTagger.nlaIII module
-----------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.nlaIII
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.universalBamTagger.rna module
--------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.rna
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.universalBamTagger.scar module
---------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.scar
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.universalBamTagger.scchic module
-----------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.scchic
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.universalBamTagger.tag module
--------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.tag
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.universalBamTagger.taps module
---------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.taps
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.universalBamTagger.tapsTabulator module
------------------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.tapsTabulator
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.universalBamTagger.tapsTagger module
---------------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.tapsTagger
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.universalBamTagger.universalBamTagger module
-----------------------------------------------------------------

.. automodule:: singlecellmultiomics.universalBamTagger.universalBamTagger
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: singlecellmultiomics.universalBamTagger
   :members:
   :undoc-members:
   :show-inheritance:
