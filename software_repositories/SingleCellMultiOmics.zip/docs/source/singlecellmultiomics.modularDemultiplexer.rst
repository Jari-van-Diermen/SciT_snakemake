singlecellmultiomics.modularDemultiplexer package
=================================================

Subpackages
-----------

.. toctree::

   singlecellmultiomics.modularDemultiplexer.demultiplexModules

Submodules
----------

singlecellmultiomics.modularDemultiplexer.baseDemultiplexMethods module
-----------------------------------------------------------------------

.. automodule:: singlecellmultiomics.modularDemultiplexer.baseDemultiplexMethods
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.modularDemultiplexer.demultiplexedFastqConversion module
-----------------------------------------------------------------------------

.. automodule:: singlecellmultiomics.modularDemultiplexer.demultiplexedFastqConversion
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.modularDemultiplexer.demultiplexingStrategyLoader module
-----------------------------------------------------------------------------

.. automodule:: singlecellmultiomics.modularDemultiplexer.demultiplexingStrategyLoader
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.modularDemultiplexer.demux module
------------------------------------------------------

.. automodule:: singlecellmultiomics.modularDemultiplexer.demux
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: singlecellmultiomics.modularDemultiplexer
   :members:
   :undoc-members:
   :show-inheritance:
