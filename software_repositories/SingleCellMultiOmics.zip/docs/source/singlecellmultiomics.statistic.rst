singlecellmultiomics.statistic package
======================================

Submodules
----------

singlecellmultiomics.statistic.allele module
--------------------------------------------

.. automodule:: singlecellmultiomics.statistic.allele
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.cellreadcount module
---------------------------------------------------

.. automodule:: singlecellmultiomics.statistic.cellreadcount
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.conversions module
-------------------------------------------------

.. automodule:: singlecellmultiomics.statistic.conversions
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.datatype module
----------------------------------------------

.. automodule:: singlecellmultiomics.statistic.datatype
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.fragmentsize module
--------------------------------------------------

.. automodule:: singlecellmultiomics.statistic.fragmentsize
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.mappingquality module
----------------------------------------------------

.. automodule:: singlecellmultiomics.statistic.mappingquality
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.methylation module
-------------------------------------------------

.. automodule:: singlecellmultiomics.statistic.methylation
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.oversequencing module
----------------------------------------------------

.. automodule:: singlecellmultiomics.statistic.oversequencing
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.plate module
-------------------------------------------

.. automodule:: singlecellmultiomics.statistic.plate
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.readcount module
-----------------------------------------------

.. automodule:: singlecellmultiomics.statistic.readcount
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.rejectionreasons module
------------------------------------------------------

.. automodule:: singlecellmultiomics.statistic.rejectionreasons
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.scchicligation module
----------------------------------------------------

.. automodule:: singlecellmultiomics.statistic.scchicligation
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.statistic module
-----------------------------------------------

.. automodule:: singlecellmultiomics.statistic.statistic
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.tag module
-----------------------------------------

.. automodule:: singlecellmultiomics.statistic.tag
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.statistic.trimming module
----------------------------------------------

.. automodule:: singlecellmultiomics.statistic.trimming
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: singlecellmultiomics.statistic
   :members:
   :undoc-members:
   :show-inheritance:
