singlecellmultiomics.fastaProcessing package
============================================

Submodules
----------

singlecellmultiomics.fastaProcessing.createMapabilityIndex module
-----------------------------------------------------------------

.. automodule:: singlecellmultiomics.fastaProcessing.createMapabilityIndex
   :members:
   :undoc-members:
   :show-inheritance:

singlecellmultiomics.fastaProcessing.fastaMaskVariants module
-------------------------------------------------------------

.. automodule:: singlecellmultiomics.fastaProcessing.fastaMaskVariants
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: singlecellmultiomics.fastaProcessing
   :members:
   :undoc-members:
   :show-inheritance:
