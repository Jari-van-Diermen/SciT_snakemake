.. SingleCellMultiOmics documentation master file, created by
   sphinx-quickstart on Tue Jul 16 11:59:02 2019.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

Welcome to SingleCellMultiOmics's documentation!
================================================

.. toctree::
   :maxdepth: 4
   :caption: Contents:


Indices and tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
