SingleCellMultiOmics
====================

.. toctree::
   :maxdepth: 4

   setup
   singlecellmultiomics
