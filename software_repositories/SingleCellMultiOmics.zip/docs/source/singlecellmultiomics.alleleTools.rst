singlecellmultiomics.alleleTools package
========================================

Submodules
----------

singlecellmultiomics.alleleTools.alleleTools module
---------------------------------------------------

.. automodule:: singlecellmultiomics.alleleTools.alleleTools
   :members:
   :undoc-members:
   :show-inheritance:


Module contents
---------------

.. automodule:: singlecellmultiomics.alleleTools
   :members:
   :undoc-members:
   :show-inheritance:
