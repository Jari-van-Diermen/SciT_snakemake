from .fastaHandle import CachedFastaNoHandle, CachedFasta
